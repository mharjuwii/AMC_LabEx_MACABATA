import React, { useState } from 'react';
import { SafeAreaView, ScrollView, View, Text, Image, TouchableOpacity, StyleSheet } from 'react-native';

const App = () => {
  const [currentSection, setCurrentSection] = useState('name');

  const resumeData = {
    imageUrl: ('https://mail.google.com/mail/u/0?ui=2&ik=d98afa047f&attid=0.1&permmsgid=msg-a:r-1589858098162038692&th=18dcad6e08e24f0e&view=fimg&fur=ip&sz=s0-l75-ft&attbid=ANGjdJ_Lx0lfN2clVrND7oYRBunFQ_xp50cOSwfC2kd1MMY2hAw0PeWihtDlzRV9LnEqEPYRrKtJ3Mz1znBGP7gCKP155hAQpxsEj4qVVL2Y_I5jfhxpVLJx0l98h6A&disp=emb&realattid=ii_lsvjtgnp0'),
    name: 'Mharjorie T. Macabata',
    course: 'Bachelor of Science in Information Technology',
    education: {
      elementary: 'Pantihan 2 Elementary School',
      elementaryYear: '2014',
      highSchool: 'Bucal National High School',
      highSchoolYear: '2018',
      college: 'Global Reciprocal Colleges',
    },
    about: 'My name is Mharjorie Macabata and I live in Caloocan City Im 21 years old and I have a brother. I love to sing and dance playing volleyball and I love to watch the sunset. My life from the beginning was very fun I am responsible and hardworking, so i study hard to obtain a good grades for the future I have a good life ',
  projects:
    {
      projectName:'Juan Kasal App: Web Based Application for Event Planning and Cost Estimation with Linear Regression.',
      imageSrc: 'https://mail.google.com/mail/u/0?ui=2&ik=d98afa047f&attid=0.1&permmsgid=msg-f:1791471186536257169&th=18dc958d72d75691&view=att&disp=safe&realattid=f_lsv4uoe50',
      link: 'file:///C:/Users/STUDENT-PC33/Downloads/WJARR-2023-2416.pdf',
      description: 'This Certificate is given by WJARR journal publishers contributed and I am the co-author of Juan Kasal App: Web Based Application for Event Planning and Cost Estimation with Linear Regression',
    },

    contact: {
    mobile: '09064320997',
    email: 'mharjoriemacabata128@gmail.com',
    },
  };

const handlePress = () => {
  setCurrentSection((prevSection) => {
    switch (prevSection) {
      case 'name':
        return 'education';
      case 'education':
        return 'about';
      case 'about':
        return 'projects'; // Move to the 'projects' section
      case 'projects':
        return 'contact'; // Move to the 'contact' section
      case 'contact':
        return 'name'; // Loop back to the start
      default:
        return 'name';
    }
  });
};

     return (
    <SafeAreaView style={{ flex: 1 }}>
      <ScrollView contentContainerStyle={styles.container}>
        <TouchableOpacity onPress={handlePress} style={styles.contentContainer}>
          {currentSection === 'name' && (
            <>
              <Image source={resumeData.imageUrl} style={styles.image} />
              <View style={styles.textContainer}>
                <Text style={styles.header}>{resumeData.name}</Text>
                <Text style={styles.info}>{resumeData.course}</Text>
              </View>
            </>
          )}

          {currentSection === 'education' && (
            <View style={styles.textContainer}>
              <Text style={styles.header1}>Education:</Text>
              <Text style={styles.projectTitle}>
                {'\n'}College:
                {'\n'}
                  </Text>
                <Text style={styles.info1}>{resumeData.education.college}</Text>
                {' | '}
                {resumeData.education.collegeYear}
            
              <Text style={styles.projectTitle}>
                {'\n'}High School:
                {'\n'}
                  </Text>
                <Text style={styles.info1}>{resumeData.education.highSchool}</Text>
                {' | '}
                {resumeData.education.highSchoolYear}
     
              <Text style={styles.projectTitle}>
                {'\n'}Elementary: 
                {'\n'}
                  </Text>
                <Text style={styles.info1}>{resumeData.education.elementary}</Text>
                {' | '}
                {resumeData.education.elementaryYear}
           
            </View>
          )}

          {currentSection === 'about' && (
            <View style={styles.textContainer}>
              <Text style={styles.header1}>About me:{'\n'}</Text>
              <Text style={styles.about}>{resumeData.about}</Text>
            </View>
          )}

{currentSection === 'projects' && (
  <View style={styles.projectsContainer}>
    <Text style={styles.header1}>Projects:</Text>
    <Text style={styles.projectTitle}>{resumeData.projects.projectName}</Text>
    <Image source={{ uri: resumeData.projects.imageSrc }} style={styles.projectImage} />
    <Text style={styles.projectLink}>{resumeData.projects.link}</Text>
    <Text style={styles.projectDescription}> {resumeData.projects.description}</Text>
  </View>
)}

{currentSection === 'projects1' && (
  <View style={styles.projectsContainer}>
     <Text style={styles.header1}>Projects:</Text>
    <Text style={styles.projectTitle}>{resumeData.projects1.projectName1}</Text>
    <Image source={{ uri: resumeData.projects1.imageSrc1 }} style={styles.projectImage} />
    <Text style={styles.projectLink}>{resumeData.projects1.link1}</Text>
    <Text style={styles.projectDescription}>{resumeData.projects1.description1}</Text>
  </View>
)}

          {currentSection === 'contact' && (
            <View style={styles.contactContainer}>
              <Text style={styles.header1}>Contact Me:{'\n'}</Text>
              <Text style={styles.info1}>
                {'\n'}Mobile: {resumeData.contact.mobile}
                {'\n'}Email: {resumeData.contact.email}
              </Text>
            </View>
          )}

        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  contentContainer: {
    alignItems: 'center',
    maxWidth: 600,
  },
  image: {
    width: 150,
    height: 150,
    borderRadius: 75,
    marginBottom: 20,
  },
  textContainer: {
    alignSelf: 'stretch',
  },
  header: {
    fontSize: 27,
    fontWeight: 'bold',
    marginBottom: 5,
    textAlign: 'center',
  },
  header1: {
    fontSize: 27,
    fontWeight: 'bold',
    marginBottom: 5,
    textAlign: 'left',
  },
  info: {
    fontSize: 21,
    alignSelf: 'flex-start',
    textAlign: 'center',
  },
  info1: {
    fontSize: 21,
    alignSelf: 'flex-start',
    textAlign: 'left',

  },
  about: {
    fontSize: 17,
    textAlign: 'left',
    alignSelf: 'flex-start',
  },
   projectsContainer: {
    alignSelf: 'stretch',
    marginTop: 20,
  },
  projectTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 5,
    textAlign: 'left',
  },
  projectImage: {
    width: 230,
    height: 230,
    marginBottom: 10,
    alignSelf: 'center',
  },
  projectLink: {
    fontSize: 13,
    marginBottom: 5,
    textAlign: 'center',
  },
  projectDescription: {
    fontSize: 15,
    marginBottom: 10,
    textAlign: 'justify',
  },


});

export default App;
